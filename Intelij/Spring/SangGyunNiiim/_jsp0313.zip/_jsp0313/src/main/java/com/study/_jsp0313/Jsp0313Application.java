package com.study._jsp0313;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jsp0313Application {

    public static void main(String[] args) {
        SpringApplication.run(Jsp0313Application.class, args);
    }

}
