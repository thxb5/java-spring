package com.study._jsp0313;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jsp0313ApplicationTests {

    @Test
    void contextLoads() {
    }

}
